#include <iostream>
#include "HCN.h"
using namespace std;
int main()
{
	HV a;
	a.setCanh(6);
	HCN b;
	b.converts(a);
	cout<<"Cac canh cua hinh cn la: ";
	b.print();
	
	return 0;
}