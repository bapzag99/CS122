#ifndef BAI4_CPP
#define BAI4_CPP

#include <iostream>
#include <string>
#include "bai2.cpp"
using namespace std;

class MayTinhXachTay: public MayTinh
{
protected:
	float CanNang;
public:
	MayTinhXachTay(Date a, string hsx, float cn): MayTinh(a,hsx), CanNang(cn)
	{}
	//setters
	void setCN(float a)
	{
		this->CanNang = a;
	}
	//getters
	float getCN() const
	{
		return this->CanNang;
	}
	int getNamSX()
	{
		return this->a.getNam();
	}
	int getSoNamSD(int as)
	{
		return as-this->a.getNam();
	}
	//
	friend ostream &operator << (ostream & out, MayTinhXachTay &bala)
	{
		cout<<bala.a<<"/"<<bala.HSX<<"/"<<bala.CanNang;
		return out;
	}
};

#endif
