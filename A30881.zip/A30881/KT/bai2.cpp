#ifndef BAI2_CPP
#define BAI2_CPP

#include <iostream>
#include <string>
#include "bai1.cpp"
using namespace std;

class MayTinh
{
protected:
	Date a;
	string HSX;
public:
	MayTinh(): a(1,1,1999), HSX(" ")
	{} 
	MayTinh(Date d, string hsx): a(d), HSX(hsx)
	{}
	//setters
	void setHSX(string a)
	{
		this->HSX = a;
	}
	//getters
	string getHSX() const
	{
		return this->HSX;
	}

	//get
	int getNamSX()
	{
		return this->a.getNam();
	}


	//
	friend ostream &operator << (ostream & out, MayTinh &mt)
	{
		cout<<mt.a<<"/"<<mt.HSX;
		return out;
	}
};
#endif