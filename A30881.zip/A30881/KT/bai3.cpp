#ifndef BAI3_CPP
#define BAI3_CPP

#include <iostream>
#include <string>
#include "bai2.cpp"
using namespace std;

class MayTinhDeBan: public MayTinh
{
protected:
	bool LoaiCase;
public:
	MayTinhDeBan(Date d, string hsx, bool b): MayTinh(d,hsx), LoaiCase(b)
	{}
	//setters
	void setCase(bool a)
	{
		this->LoaiCase = a;
	}
	//getters
	bool getCase() const
	{
		return this->LoaiCase;
	}
	//Phuong thuc
	int getNamSX()
	{
		return this->a.getNam();
	}
	bool XetLoaiCase()
	{
		if (this->LoaiCase = 1)
			return true;
		return false;
	}

	friend ostream &operator << (ostream & out, MayTinhDeBan &xyz)
	{
		cout<<xyz.a<<"/"<<xyz.HSX<<"/"<<xyz.LoaiCase;
		return out;
	}


};

#endif