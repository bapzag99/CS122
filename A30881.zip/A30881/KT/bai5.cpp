#include <iostream>
#include <string>
#include "bai3.cpp"
#include "bai4.cpp"
using namespace std;
int main()
{
	Date d1(18,6,2014), d2(1,1,2014);
	cout<<d1<<"; "<<d2<<endl;
	MayTinh m1(d1,"Dell"), m2(d2,"HP"); cout<<m1.getNamSX()<<endl;
	MayTinhDeBan mb1(d1,"Dell",true);
	MayTinhXachTay mt1(d2,"Sony",2.2);
	cout<<mb1.getNamSX()<<endl;
	cout<<mt1.getNamSX()<<endl;
	cout<<mt1.getSoNamSD(2017)<<endl;

	return 0;
}