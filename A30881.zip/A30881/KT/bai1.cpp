#ifndef BAI1_CPP
#define BAI1_CPP

#include <iostream>
using namespace std;

class Date
{
protected:
	int Ngay;
	int Thang;
	int Nam;
public:
	Date() : Ngay(0), Thang(0), Nam(0)
	{}
	Date(int a, int b, int c) : Ngay(a), Thang(b), Nam(c)
	{}
	//setters
	void setNgay(int a)
	{
		this->Ngay = a;
	}
	void setThang(int a)
	{
		this->Thang = a;
	}
	void setNam(int a)
	{
		this->Nam = a;
	}
	//getters
	int getNgay() const
	{
		return this->Ngay;
	}
	int getThang() const
	{
		return this->Thang;
	}
	int getNam() const
	{
		return this->Nam;
	}
	//
	friend ostream &operator << (ostream & out, Date &a)
	{
		cout<<a.Ngay<<"/"<<a.Thang<<"/"<<a.Nam;
		return out;
	}
};

#endif