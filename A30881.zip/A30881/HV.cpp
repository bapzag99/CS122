#ifndef HV_H
#define HV_H
#include <iostream>
using namespace std;

class HV
{
protected:
	float Canh;
public:
	HV(): Canh(0)
	{}
	HV(float a): Canh(a)
	{} 
	//Settes
	void setCanh(float a)
	{
		this->Canh = a;
	}
	//Getters
	float getCanh() const
	{
		return this->Canh;
	}
	//
	friend class HCN;
};


#endif