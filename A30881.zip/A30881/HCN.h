#ifndef HCN_H
#define HCN_H
#include <iostream>
#include "HV.cpp"
using namespace std;

class HCN
{
protected:
	float ChieuDai;
	float ChieuRong;
public:
	HCN(): ChieuDai(0),ChieuRong(0)
	{}
	HCN(float a, float b): ChieuDai(a), ChieuRong(b)
	{}
	//Setters
	void setCD(float a)
	{
		this->ChieuDai = a;
	}
	void setCR(float a)
	{
		this->ChieuRong = a;
	}
	//Getters
	float getCD() const
	{
		return this->ChieuDai;
	}
	float getCR() const
	{
		return this->ChieuRong;
	}
	//
	void converts (HV a);

	void print() const
	{
		cout<<this->ChieuDai<<"/////"<<this->ChieuRong<<endl;
	}
};
void HCN::converts (HV a)
{
	ChieuDai = a.Canh;
	ChieuRong = a.Canh;
}

#endif